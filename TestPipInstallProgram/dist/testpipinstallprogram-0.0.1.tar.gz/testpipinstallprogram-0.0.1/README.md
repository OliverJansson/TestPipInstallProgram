
# Test Pip Install Program
    This is a test program for learning to cerate and assemble a pip installable work library

# Content
    The libiray has 4 functions in the simple_calc: attraction, subtraction, multiplication and division. 

# Instructions 
    1. Install:
        Pip install TestPipInstallprogram

    2. Use functions:
        In python:
            from TestPipInstallprogram import simple_calc

        Four functions:
            -------
            attraction(a,b): adds a and b together.
            --------

            -------
            subtraction(a,b): subtracts b from a.
            --------

            -------
            multiplication(a,b): multiply a and b togehter.
            --------

            -------
            division(a,b): divides a by b.
            --------





